<template>
  <vue-command :yargs-options="{ alias: { color: ['colour'] } }" :commands="commands"/>
</template>

<script>
import VueCommand from "vue-command";
import "vue-command/dist/vue-command.css";

export default {
  components: {
    VueCommand
  },

  data: () => ({
    commands: {
      // yargs arguments
      pokedex: ({ color, _ }) => {
        if (color && _[1] === "pikachu") return "yellow";

        return `Usage: pokedex pokemon [option]<br><br>

        Example: pokedex pikachu --color
        `;
      }
    }
  })
};
</script>

<style lang="scss">
.vue-command {
  .term {
    -webkit-border-radius: 8px;
    -moz-border-radius: 8px;
    border-radius: 8px;
  }

  .term-std {
    width: 962px;
    height: 649px;
    overflow-y: scroll;
  }
}
</style>